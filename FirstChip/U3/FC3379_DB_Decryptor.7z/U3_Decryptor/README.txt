使用方式：拖 cfgU3.bin 到 U3_Decryptor.exe，不要关闭，然后生成两个文件，编辑 csv 并且保存，然后确保 Excel 已经关闭退出，在旧窗口按回车即可导入数据库。

By LXY 2023.08.24
禁止量产吧转载收录
EVA群专供