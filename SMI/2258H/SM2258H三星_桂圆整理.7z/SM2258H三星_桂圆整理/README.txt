POWERED BY LONGANADE
默认工具为Q0720A Q0807A 此版本较为通用
通吃MLC颗粒 TLC比较阴间且有矿坏的可能
2D TLC请选择Q0612A 开卡较难 速度慢
SSV4请选择S0702A 不稳定 自行斟酌
市面公开的软件版本均已收录
删除无用文件
SSV1颗粒参数为自己编写
其他FLASH.SET均为网络搜集 十分全面